package com.cisco.dsusingjava.sortingexamples;

import java.util.Scanner;

public class BubbleSortExample {

	public static void main(String[] args) {
		
		int[] arr = new int[10];
		int sValue;
		Scanner sc = new Scanner(System.in);
			System.out.println("Enter the values in to the array");
			for(int i=0;i<arr.length;i++) {
				arr[i] = sc.nextInt();
			}
		bubbleSorting(arr);
		
		//print after the sort
		System.out.println("After Sorting......");
		System.out.println("========================");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}

	}

	public static void bubbleSorting(int[] arr) {
		int len = arr.length;
		int temp = 0;
		for(int i=0;i<arr.length;i++) {
			for(int j=1;j<len;j++) {
				if(arr[j-1] > arr[j]) {
					temp = arr[j-1];
					arr[j-1] = arr[j];
					arr[j] = temp;
				}
			}
		}
		
	}

}
