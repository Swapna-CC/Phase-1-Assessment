package com.cisco.dsusingjava.searchingexamples;

public class MainExample {

	public static void main(String[] args) {
		LinearSearchExample lse = new LinearSearchExample();
		lse.readValues();
		if(lse.linearSearch() == -1) {
			System.out.println("Search Element not Found");
		}else {
			System.out.println("Element Found");
		}

	}

}
