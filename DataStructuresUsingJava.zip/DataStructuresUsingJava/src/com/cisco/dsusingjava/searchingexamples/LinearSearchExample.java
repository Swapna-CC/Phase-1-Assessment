package com.cisco.dsusingjava.searchingexamples;

import java.util.Scanner;

public class LinearSearchExample {
	int[] arr = new int[10];
	int sValue;
	Scanner sc = new Scanner(System.in);
	public void readValues() {
		
	
		System.out.println("Enter the values in to the array");
		for(int i=0;i<arr.length;i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter the Search Value");
		 sValue = sc.nextInt();
		
	}
	
	public int linearSearch() {
		for(int i=0;i<arr.length;i++) {
			if(arr[i] == sValue) {
				return i;
			}
		}
		return -1;
	}

}
