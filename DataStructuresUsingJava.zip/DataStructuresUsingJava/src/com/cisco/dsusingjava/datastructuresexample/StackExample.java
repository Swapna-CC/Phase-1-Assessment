package com.cisco.dsusingjava.datastructuresexample;

public class StackExample {
	
	static final int MAX = 100;
	int top;
	int a[] = new int[MAX];
	
	boolean isEmpty() {
		return (top < 0);
	}
	
	public StackExample() {
		top = -1;
	}
	
	//add elements in to stack
	boolean push(int x) {
		if(top > (MAX - 1)) {
			System.out.println("stack overflow or full");
			return false;
		}else {
			a[++top] = x;
			System.out.println(x + "pushed in to the stack");
			return true;
		}
	}
	
	//remove elements from the stack
	
	int pop() {
		if(top < 0) {
			System.out.println("stack is empty or underflow");
			return 0;
		}else {
			int x = a[top--];
			return x;
		}
	}
	
	public static void main(String[] a) {
		StackExample se = new StackExample();
		se.push(23);
		se.push(13);
		se.push(15);
		se.push(18);
		
		System.out.println(se.pop() + "popped from the stack");
	}

}
