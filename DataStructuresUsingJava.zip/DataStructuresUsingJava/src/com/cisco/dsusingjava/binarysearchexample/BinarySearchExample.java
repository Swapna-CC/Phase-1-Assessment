package com.cisco.dsusingjava.binarysearchexample;

import java.util.Scanner;

public class BinarySearchExample {
	int[] arr = new int[10];
	int sValue;
	Scanner sc = new Scanner(System.in);
	public void readValues() {
		System.out.println("Enter the values in to the array In Ascending Order");
		for(int i=0;i<arr.length;i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter the Search Value");
		 sValue = sc.nextInt();
		
	}
	
	public void binarySearch() {
		int start = 0,end = arr.length;
		//calculate mid element 
		int midElement = (start + end)/2;
		while (start <= end) {
			if(arr[midElement] < sValue) {
				start = midElement + 1;
			}else if(arr[midElement] == sValue){
				System.out.println("Element found at index ="+midElement);
				break;
			}else {
				end = midElement - 1;
			}
			midElement = (start + end)/2;
		}
		
		if(start > midElement) {
			System.out.println("Element is not found...");
		}
	}
}
