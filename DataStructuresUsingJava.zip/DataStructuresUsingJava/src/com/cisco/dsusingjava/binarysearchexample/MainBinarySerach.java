package com.cisco.dsusingjava.binarysearchexample;

public class MainBinarySerach {

	public static void main(String[] args) {
		BinarySearchExample bse = new BinarySearchExample();
		bse.readValues();
		bse.binarySearch();
	}

}
